export const INCREMENT = 'example.counter.INCREMENT';
export const DECREMENT = 'example.counter.DECREMENT';
