import React, {Component} from "react";

export default class TopTabsScreen extends Component {
  render() {
    return null;
  }
}
