import App from './src/app';

const app = new App();
