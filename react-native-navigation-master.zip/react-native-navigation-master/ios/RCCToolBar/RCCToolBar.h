//
//  RCCToolBar.h
//  ReactNativeControllers
//
//  Created by Ran Greenberg on 09/05/2016.
//  Copyright © 2016 artal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <React/RCTViewManager.h>

@interface RCCToolBar : RCTViewManager

@end
