package com.reactnativenavigation.events;

public interface Subscriber {
    void onEvent(Event event);
}
