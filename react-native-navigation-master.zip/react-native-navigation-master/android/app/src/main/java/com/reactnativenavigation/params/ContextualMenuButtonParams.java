package com.reactnativenavigation.params;

public class ContextualMenuButtonParams extends TitleBarButtonParams {
    public int index;
}
