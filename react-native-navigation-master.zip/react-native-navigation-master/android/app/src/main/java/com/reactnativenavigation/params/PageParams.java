package com.reactnativenavigation.params;

public class PageParams extends BaseScreenParams {


}
